import { defaultAvatarModels } from "@/config/avatarModels.default";
import { NextRequest,NextResponse } from "next/server";
import { isAdmin,sameOrigin } from "@/lib/avatarAdmin";
import { readAvatarConfigStateV658,updateAvatarMetadata,blobModels,useBlob } from "@/lib/avatarBlob";
import { readdir } from "node:fs/promises";
import path from "node:path";
import {AvatarRevisionConflictV658,AvatarConfigUnsafeV658,revisionV658} from "@/lib/avatarConfigSafetyV658";
export const runtime="nodejs";export const dynamic="force-dynamic";
const presets=new Set(["auto","hardstyle","techno","rock-metal","robot","ambient","freestyle"]);
export async function GET(){
 if(!await isAdmin())return NextResponse.json({error:"Nicht angemeldet"},{status:401});
 try {const state=await readAvatarConfigStateV658();return NextResponse.json({metadata:state.metadata,revisions:state.revisions,emptyRevision:revisionV658({}),diagnostics:state.diagnostics},{headers:{"Cache-Control":"no-store"}});}
 catch(error){console.error("Avatar config read",error);return NextResponse.json({error:"Konfiguration nicht lesbar – kein Speichern möglich"},{status:503});}
}
export async function PATCH(req:NextRequest){if(!await isAdmin())return NextResponse.json({error:"Nicht angemeldet"},{status:401});if(!sameOrigin(req))return NextResponse.json({error:"Origin mismatch"},{status:403});if(Number(req.headers.get("content-length")||0)>10000)return NextResponse.json({error:"Zu groß"},{status:413});try { const body=await req.json();const filename=body?.filename;const m=body?.metadata;const expectedRevision=body?.expectedRevision;
if(expectedRevision!==undefined&&(typeof expectedRevision!=="string"||!/^[a-f0-9]{64}$/.test(expectedRevision)))return NextResponse.json({error:"Ungültige Versionskennung"},{status:400});
const isDefault=typeof filename==="string"&&defaultAvatarModels.some(x=>`default:${x.id}`===filename);if(typeof filename!=="string"||(!isDefault&&(!/^[a-zA-Z0-9][a-zA-Z0-9_. -]*\.(glb|gltf)$/i.test(filename)||filename.includes("..")||filename.length>180))||!m||typeof m!=="object"||Array.isArray(m))return NextResponse.json({error:"Ungültige Eingabe"},{status:400});const files=isDefault?[]:useBlob?(await blobModels()).map(b=>b.pathname.split("/").pop()):await readdir(path.join(process.cwd(),"public","avatars"));if(!isDefault&&!files.includes(filename))return NextResponse.json({error:"Modell nicht gefunden"},{status:404});const str=(key:string,max:number)=>typeof m[key]==="string"&&m[key].length<=max?m[key].trim():null;const list=(key:string)=>Array.isArray(m[key])&&m[key].length<=20&&m[key].every((v:unknown)=>typeof v==="string"&&v.length<=50)?m[key].map((v:string)=>v.trim()).filter(Boolean):null;const label=str("label",100),description=str("description",500),preview=str("preview",500),category=str("category",80),genre=list("genre"),tags=list("tags");if(label===null||description===null||preview===null||category===null||genre===null||tags===null||typeof m.favorite!=="boolean"||(preview&&!preview.startsWith("/")&&!preview.startsWith("https://"))||(preview.startsWith("//"))||(m.defaultDancePreset!==undefined&&!presets.has(m.defaultDancePreset)))return NextResponse.json({error:"Ungültige Eigenschaften"},{status:400});const modelUrl=m.modelUrl;if(isDefault&&filename!=="default:procedural"&&modelUrl!==undefined&&(typeof modelUrl!=="string"||modelUrl.length>500||(modelUrl&&!/^https:\/\/[^\s]+\.glb(?:\?[^\s]*)?$/.test(modelUrl)&&!/^\/avatars\/[^\s]+\.glb$/.test(modelUrl))))return NextResponse.json({error:"Ungültige GLB-URL"},{status:400});const animationUrl=m.animationUrl;
if(animationUrl!==undefined&&(typeof animationUrl!=="string"||animationUrl.length>700||(animationUrl&&!/^https:\/\/[^\s]+\.glb(?:\?[^\s]*)?$/.test(animationUrl)&&!/^\/animations\/[a-zA-Z0-9_.-]+\.glb$/.test(animationUrl))))return NextResponse.json({error:"Ungültige Animations-GLB-URL"},{status:400});
const sharedMotionUrl=m.sharedMotionUrl;
if(sharedMotionUrl!==undefined&&(typeof sharedMotionUrl!=="string"||sharedMotionUrl.length>700||
 (sharedMotionUrl&&!/^https:\/\/[^\s]+\.glb(?:\?[^\s]*)?$/.test(sharedMotionUrl)&&!/^\/avatars\/[a-zA-Z0-9_.%-]+\.glb$/.test(sharedMotionUrl))))
 return NextResponse.json({error:"Ungültige Shared-Motion-URL"},{status:400});
const fingerprint=m.sharedMotionFingerprint,rigFingerprint=m.sharedRigFingerprint;
const clipCount=m.sharedMotionClipCount;
if((fingerprint!==undefined&&!/^[a-f0-9]{64}$/.test(fingerprint))||(rigFingerprint!==undefined&&!/^[a-f0-9]{64}$/.test(rigFingerprint))||
 (clipCount!==undefined&&(!Number.isInteger(clipCount)||clipCount<1||clipCount>200)))
 return NextResponse.json({error:"Ungültige Shared-Motion-Signatur"},{status:400});
// A shared source must actually be a registered avatar; refuse dangling external URLs.
if(sharedMotionUrl){const registered=new Set([...useBlob?(await blobModels()).map(b=>b.url):
 (await readdir(path.join(process.cwd(),"public","avatars"))).filter(f=>/\.glb$/i.test(f)).map(f=>`/avatars/${encodeURIComponent(f)}`),
 ...defaultAvatarModels.map(d=>d.url).filter((v):v is string=>!!v)]);
 if(!registered.has(sharedMotionUrl))return NextResponse.json({error:"Gemeinsame Motion-Quelle nicht installiert"},{status:400});}
await updateAvatarMetadata(filename,{label,description,preview,category,genre,tags,favorite:m.favorite,
 defaultDancePreset:m.defaultDancePreset,animationUrl:animationUrl||"",
 ...(sharedMotionUrl!==undefined?{sharedMotionUrl}:{ }),
 ...(fingerprint!==undefined?{sharedMotionFingerprint:fingerprint}:{ }),
 ...(rigFingerprint!==undefined?{sharedRigFingerprint:rigFingerprint}:{ }),
 ...(clipCount!==undefined?{sharedMotionClipCount:clipCount}:{ }),
 ...(isDefault&&filename!=="default:procedural"?{modelUrl}:{})},{expectedRevision});
const current=await readAvatarConfigStateV658();return NextResponse.json({ok:true,revision:current.revisions[filename]},{headers:{"Cache-Control":"no-store"}});
}catch(e){
 if(e instanceof AvatarRevisionConflictV658)return NextResponse.json({error:e.message,currentRevision:e.actualRevision},{status:409});
 if(e instanceof AvatarConfigUnsafeV658)return NextResponse.json({error:e.message},{status:503});
 console.error(e);return NextResponse.json({error:"Speichern fehlgeschlagen; Status vor erneutem Versuch prüfen"},{status:500});
}}
