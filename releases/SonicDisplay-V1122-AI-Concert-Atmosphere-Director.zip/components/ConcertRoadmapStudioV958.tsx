'use client';
import {useEffect,useMemo,useState} from 'react';
import {AlexaConcertControlV967} from '@/components/AlexaConcertControlV967';
import {useMusic} from '@/context/MusicContext';
import {concertContinuityAuditV960} from '@/lib/concertContinuityV960';
import type {GoveeConfigV909,GoveeDeviceV909} from '@/lib/goveeLanV909';
import {loadGoveeSpatialV926,saveGoveeSpatialV926} from '@/lib/goveeSpatialDirectorV926';
import {loadGoveeCalibrationV927} from '@/lib/goveeRoomCalibrationV927';
import {readTrackAnalysisV318,ANALYSIS_EVENT_V318,ANALYSIS_STORAGE_KEY_V318,type TrackAnalysisV318} from '@/services/musicAnalysis/trackAnalysisV318';
import {composeConcertSceneV958,rehearseConcertV938,qualityImportedConcertV957,loadConcertRoadmapV958,saveConcertRoadmapV958,
 upsertRoomPresetV936,latencyAnalysisV932,CONCERT_SIGNAL_EVENT_V933,CONCERT_ROADMAP_EVENT_V958,
 type ConcertSettingsV958,type ConcertPhaseV958,type ConcertRoleV935,type ConcertCameraV940,
 type ConcertDanceV941,type ConcertFxV955,type ConcertSignalV933} from '@/lib/ultimateConcertRoadmapV958';

const phaseOptions:ConcertPhaseV958[]=['verse','hook','build','drop','break','outro'];
const roles:ConcertRoleV935[]=['spotlight','rhythm','backdrop','audience','accent'];
const cameraOptions:ConcertCameraV940[]=['wide','medium','close','orbit'];
const formationOptions:ConcertDanceV941[]=['solo','duet','sync','mirror'];
const fxOptions:ConcertFxV955[]=['beams','lasers','sweep','bass-impact','fog','confetti','streamers'];
export function ConcertRoadmapStudioV958({config,devices,onConfig}:{config:GoveeConfigV909;devices:GoveeDeviceV909[];
 onConfig:(patch:Partial<GoveeConfigV909>)=>void}){
 const {track,genre}=useMusic();
 const [settings,setSettings]=useState<ConcertSettingsV958|null>(null);
 const [phase,setPhase]=useState<ConcertPhaseV958>('hook');const [position,setPosition]=useState(60);
 const [presetName,setPresetName]=useState('Mein Konzertraum');const [selectedPreset,setSelectedPreset]=useState('');
 const [camera,setCamera]=useState<ConcertCameraV940>('wide');
 const [formation,setFormation]=useState<ConcertDanceV941>('sync');const [effect,setEffect]=useState<ConcertFxV955>('beams');
 const [signals,setSignals]=useState<ConcertSignalV933[]>([]);const [notice,setNotice]=useState('');
 const [actualAnalysis,setActualAnalysis]=useState<TrackAnalysisV318|null>(null);
 useEffect(()=>{setSettings(loadConcertRoadmapV958());
  const receive=(event:Event)=>{const msg=(event as CustomEvent<ConcertSignalV933>).detail;
   if(msg&&Number.isSafeInteger(msg.fixture)&&msg.fixture>=1&&msg.fixture<=32&&Number.isFinite(msg.atMs))
    setSignals(previous=>[...previous.filter(s=>s.fixture!==msg.fixture),msg].slice(-32));};
  window.addEventListener(CONCERT_SIGNAL_EVENT_V933,receive);
  return()=>window.removeEventListener(CONCERT_SIGNAL_EVENT_V933,receive);
 },[]);
 useEffect(()=>{const refresh=()=>setSettings(loadConcertRoadmapV958());
  window.addEventListener(CONCERT_ROADMAP_EVENT_V958,refresh);
  return()=>window.removeEventListener(CONCERT_ROADMAP_EVENT_V958,refresh);
 },[]);
 useEffect(()=>{
  const refresh=()=>setActualAnalysis(readTrackAnalysisV318(track?.id||''));
  const storage=(event:StorageEvent)=>{if(!event.key||event.key===ANALYSIS_STORAGE_KEY_V318)refresh();};
  refresh();window.addEventListener(ANALYSIS_EVENT_V318,refresh);window.addEventListener('storage',storage);
  return()=>{window.removeEventListener(ANALYSIS_EVENT_V318,refresh);window.removeEventListener('storage',storage);};
 },[track?.id]);
 const save=(patch:Partial<ConcertSettingsV958>)=>{
  if(!settings)return;
  const result={...settings,...patch};try{saveConcertRoadmapV958(result);setSettings(loadConcertRoadmapV958());}
  catch{setNotice('Speichern nicht möglich: lokalen Speicher und Speicherplatz prüfen.');}
 };
 const duration=track?.durationMs||180000;
 const previewAt=Math.round(duration*position/100);
 const scene=useMemo(()=>settings?composeConcertSceneV958({trackId:track?.id||'rehearsal',progressMs:previewAt,
  durationMs:duration,phase,sectionIndex:Math.floor(position/8),sectionStartMs:Math.max(0,previewAt-2000),
  verified:false,genre:String(genre||''),energy:.7,bass:.7,lyricsVisible:false,reducedMotion:false},settings):null,
 [settings,track?.id,previewAt,duration,phase,position,genre]);
 const rehearsal=useMemo(()=>settings?rehearseConcertV938(track?.id||'rehearsal',duration,String(genre||''),settings):null,
  [settings,track?.id,duration,genre]);
 const continuity=useMemo(()=>rehearsal?concertContinuityAuditV960(rehearsal.scenes,true):null,[rehearsal]);
 const realQuality=useMemo(()=>settings?qualityImportedConcertV957(actualAnalysis,String(genre||''),settings):null,
  [actualAnalysis,genre,settings]);
 const addPreset=()=>{if(!settings||!config.selectedIps.length)return;
  const spatial=loadGoveeSpatialV926();const id=`room-${Date.now()}`;
  const rolesValue:Record<string,ConcertRoleV935>={};
  const positions:Record<string,{x:number;y:number}>={};
  config.selectedIps.forEach((ip,i)=>{rolesValue[ip]=settings.roleOverrides[ip]||roles[i%roles.length];
   positions[ip]=spatial.positions[ip]||{x:.2+.6*(i%2),y:.2+.6*Math.floor(i/2)/Math.max(1,Math.ceil(config.selectedIps.length/2)-1)};});
  const s=upsertRoomPresetV936(settings,{id,name:presetName,roles:rolesValue,positions});save(s);setSelectedPreset(id);
  setNotice('Raumpreset lokal gespeichert. Die laufende Show wurde nicht verändert.');};
 const applyPreset=()=>{const preset=settings?.presets.find(p=>p.id===selectedPreset);if(!preset)return;
  // Explicit user action; only V926 positions and new V935 roles. Existing V912 shows are untouched.
  save({roleOverrides:preset.roles});saveGoveeSpatialV926({...loadGoveeSpatialV926(),positions:preset.positions});
  setNotice('Raumpositionen und neue Konzertrollen übernommen. Vorhandene Lichtshows bleiben unverändert.');};
 const addTimeline=()=>{if(!track?.id||!settings)return;
  const current=settings.timeline[track.id]||[];
  save({timeline:{...settings.timeline,[track.id]:[...current,{atMs:previewAt,phase,camera,formation,effect}].sort((a,b)=>a.atMs-b.atMs)}});
  setNotice('Manuellen Regie-Cue gespeichert. Er ersetzt keine vorhandene V354-Show-Timeline.');};
 const changeTimeline=(index:number,patch:Partial<NonNullable<ConcertSettingsV958['timeline'][string]>[number]>)=>{
  if(!track?.id||!settings)return;
  const updated=(settings.timeline[track.id]||[]).map((cue,i)=>i===index?{...cue,...patch}:cue).sort((a,b)=>a.atMs-b.atMs);
  save({timeline:{...settings.timeline,[track.id]:updated}});
 };
 const deleteTimeline=(index:number)=>{
  if(!track?.id||!settings)return;
  save({timeline:{...settings.timeline,[track.id]:(settings.timeline[track.id]||[]).filter((_,i)=>i!==index)}});
 };
 const calibration=typeof window!=='undefined'?loadGoveeCalibrationV927():null;
 if(!settings)return <p className="settings-note">Concert Studio wird geladen …</p>;
 return <section className="govee-v958" aria-label="V930 bis V958 Ultimate Concert Experience">
  <h3>V930–V958 · Ultimate Concert Experience Studio</h3>
  <p className="settings-note">Konzertdramaturgie, Vorschau und Gerätesignale – ohne zusätzliche LAN-Timer. Bestehende manuelle Govee-Lichtshows und die V354-Bühnen-Timeline behalten Vorrang.</p>
  <div className="govee-v958-settings">
   <label><input type="checkbox" checked={settings.enabled} onChange={e=>save({enabled:e.target.checked})}/> Intelligente Konzertregie aktivieren</label>
   <label><input type="checkbox" checked={settings.virtualFx} disabled={!settings.enabled} onChange={e=>save({virtualFx:e.target.checked})}/> Virtuelle 3D-Bühneneffekte aktivieren</label>
   <label><input type="checkbox" checked={settings.hardwareSync} disabled={!settings.enabled} onChange={e=>save({hardwareSync:e.target.checked})}/> Konzert-Cues zusätzlich dezent an Govee-LAN übertragen (opt-in)</label>
   <label><input type="checkbox" checked={settings.transitionsV960} disabled={!settings.enabled}
    onChange={e=>save({transitionsV960:e.target.checked})}/> V960: Sanfte Verse/Hook/Drop-Übergänge (nur bestätigte Abschnitte)</label>
   <label><input type="checkbox" checked={settings.compactFxV960} disabled={!settings.enabled||!settings.virtualFx}
    onChange={e=>save({compactFxV960:e.target.checked})}/> V960: Kompaktes 3D-FX-Profil (maximal zwei Effekte)</label>
   <label><input type="checkbox" checked={settings.lightGovernorV961} disabled={!settings.enabled||!settings.hardwareSync}
    onChange={e=>save({lightGovernorV961:e.target.checked})}/> V961: Sanfte Govee-Lichtwechsel (max. +12% Helligkeit und 40 RGB-Stufen je vorhandenem Auto-Sync-Tick)</label>
   <label><input type="checkbox" checked={settings.narrativeV962} disabled={!settings.enabled||!settings.hardwareSync}
    onChange={e=>save({narrativeV962:e.target.checked})}/> V962: Songdramaturgie für Govee (Verse/Hook/Build/Drop/Break/Outro – nur bestätigte Abschnitte)</label>
   <label><input type="checkbox" checked={settings.bridgeV963} disabled={!settings.enabled||!settings.hardwareSync}
    onChange={e=>save({bridgeV963:e.target.checked})}/> V963: Spannungsaufbau vor bestätigten Hook-/Drop-Wechseln (keine zusätzlichen Govee-Befehle; manuelle Shows geschützt)</label>
   <label><input type="checkbox" checked={settings.peakRecoveryV964} disabled={!settings.enabled||!settings.hardwareSync}
    onChange={e=>save({peakRecoveryV964:e.target.checked})}/> V964: Kurze Erholungsphase nach bestätigten Hook-/Drop-Spitzen (nur automatische Govee-Cues)</label>
   <label><input type="checkbox" checked={settings.roomWaveV965} disabled={!settings.enabled||!settings.hardwareSync}
    onChange={e=>save({roomWaveV965:e.target.checked})}/> V965: Langsame, genreabhängige Lichtwelle durch den Raum bei bestätigten Hooks und Drops (mindestens zwei Lampen; keine Blitze)</label>
   <label><input type="checkbox" checked={settings.immersiveV966} disabled={!settings.enabled||!settings.virtualFx}
    onChange={e=>save({immersiveV966:e.target.checked})}/> V966: Immersive Konzertatmosphäre – räumliche Lichtkegel, Bühnenhintergrund und Publikumsrand (nur virtuell; keine Lichtblitze)</label>
   <label>V966 Immersion: {settings.immersiveStrengthV966}% <input type="range" min={0} max={100} step={5}
    value={settings.immersiveStrengthV966} disabled={!settings.enabled||!settings.virtualFx||!settings.immersiveV966}
    onChange={e=>save({immersiveStrengthV966:Number(e.target.value)})}/></label>
   <h4>V988 · Holographic Stage Portal</h4>
   <label><input type="checkbox" checked={settings.portalV988}
    disabled={!settings.enabled||!settings.virtualFx||!settings.immersiveV966}
    onChange={e=>save({portalV988:e.target.checked})}/>
    Holografisches Bühnenportal und räumlichen Lichttunnel aktivieren (nur virtuelle, bestätigte Songszenen)</label>
   <label>V988 · Portalstil <select aria-label="V988 Portalstil" value={settings.portalModeV988}
    disabled={!settings.enabled||!settings.virtualFx||!settings.immersiveV966||!settings.portalV988}
    onChange={e=>save({portalModeV988:e.target.value as ConcertSettingsV958['portalModeV988']})}>
    <option value="auto">Dynamisch nach Songphase</option><option value="arch">Holografische Bögen</option>
    <option value="tunnel">3D-Lichttunnel</option>
   </select></label>
   <label>V988 · Intensität {settings.portalStrengthV988}% <input type="range" min={0} max={100} step={5}
    value={settings.portalStrengthV988}
    disabled={!settings.enabled||!settings.virtualFx||!settings.immersiveV966||!settings.portalV988}
    onChange={e=>save({portalStrengthV988:Number(e.target.value)})}/></label>
   <p className="settings-note">Das Portal bleibt hinter Künstlern und LED-Bühnenwand, pausiert bei manuellen
    Szenen oder Performance-Sparprofilen und zeigt bei reduzierter Bewegung nur ruhige Formen.
    Keine Blitze, keine zusätzlichen Lampen oder Govee-Befehle.</p>
   <label><input type="checkbox" checked={settings.energyArcV975} disabled={!settings.enabled||!settings.virtualFx}
    onChange={e=>save({energyArcV975:e.target.checked})}/> V975: Adaptive Konzert-Energiekurve (nur virtuelle Bühne und bestätigte Songabschnitte)</label>
   <label>V975 · Dynamik <select value={settings.energyArcModeV975} disabled={!settings.energyArcV975||!settings.enabled||!settings.virtualFx}
    onChange={e=>save({energyArcModeV975:e.target.value as ConcertSettingsV958['energyArcModeV975']})}>
    <option value="subtle">Dezent</option><option value="balanced">Ausgewogen</option><option value="cinematic">Filmisch</option>
   </select></label>
   <label>V975 · Intensität {settings.energyArcStrengthV975}% <input type="range" min={0} max={100} step={5}
    disabled={!settings.energyArcV975||!settings.enabled||!settings.virtualFx}
    value={settings.energyArcStrengthV975} onChange={e=>save({energyArcStrengthV975:Number(e.target.value)})}/></label>
   <label><input type="checkbox" checked={settings.intelligentTransitionsV976} disabled={!settings.enabled||!settings.virtualFx}
    onChange={e=>save({intelligentTransitionsV976:e.target.checked})}/> V976: Intelligent Concert Transitions – weiche virtuelle Licht- und Kameraübergänge</label>
   <label>V976 · Übergangsstil <select value={settings.transitionStyleV976}
    disabled={!settings.enabled||!settings.virtualFx||!settings.intelligentTransitionsV976}
    onChange={e=>save({transitionStyleV976:e.target.value as ConcertSettingsV958['transitionStyleV976']})}>
    <option value="gentle">Sanft</option><option value="balanced">Ausgewogen</option><option value="dramatic">Dynamisch</option>
   </select></label>
   <label>V976 · Stärke {settings.transitionStrengthV976}% <input type="range" min={0} max={100} step={5}
    disabled={!settings.enabled||!settings.virtualFx||!settings.intelligentTransitionsV976}
    value={settings.transitionStrengthV976} onChange={e=>save({transitionStrengthV976:Number(e.target.value)})}/></label>
   <label><input type="checkbox" checked={settings.cameraHandoffsV976}
    disabled={!settings.enabled||!settings.virtualFx||!settings.intelligentTransitionsV976}
    onChange={e=>save({cameraHandoffsV976:e.target.checked})}/> V976: Weiche automatische Kameraübergaben (keine manuellen Kameracues)</label>
   <label><input type="checkbox" checked={settings.storytellingV977} disabled={!settings.enabled||!settings.virtualFx}
    onChange={e=>save({storytellingV977:e.target.checked})}/> V977: Smart Concert Storytelling – dramaturgischer Spannungsbogen für bestätigte Songabschnitte</label>
   <label>V977 · Inszenierung <select aria-label="V977 Erzählstil" value={settings.storytellingModeV977}
    disabled={!settings.enabled||!settings.virtualFx||!settings.storytellingV977}
    onChange={e=>save({storytellingModeV977:e.target.value as ConcertSettingsV958['storytellingModeV977']})}>
    <option value="subtle">Dezent</option><option value="cinematic">Filmisch</option><option value="festival">Festival</option>
   </select></label>
   <label>V977 · Stärke {settings.storytellingStrengthV977}% <input type="range" min={0} max={100} step={5}
    disabled={!settings.enabled||!settings.virtualFx||!settings.storytellingV977}
    value={settings.storytellingStrengthV977} onChange={e=>save({storytellingStrengthV977:Number(e.target.value)})}/></label>
   <label><input type="checkbox" checked={settings.storytellingAccentsV977}
    disabled={!settings.enabled||!settings.virtualFx||!settings.storytellingV977}
    onChange={e=>save({storytellingAccentsV977:e.target.checked})}/> V977: Ruhige, optionale Sweep-Akzente in bestätigten Hooks/Drops und beim Outro-Finale</label>
   <h4>V979 · Intelligent Live Show Director 3.0</h4>
   <label><input type="checkbox" checked={settings.liveShowDirectorV979}
    disabled={!settings.enabled||!settings.virtualFx}
    onChange={e=>save({liveShowDirectorV979:e.target.checked})}/> V979: Gemeinsame Konzertregie mit Bühnen- und Effektbudget</label>
   <label>V979 · Regiestil <select aria-label="V979 Regiestil" value={settings.liveShowStyleV979}
    disabled={!settings.enabled||!settings.virtualFx||!settings.liveShowDirectorV979}
    onChange={e=>save({liveShowStyleV979:e.target.value as ConcertSettingsV958['liveShowStyleV979']})}>
    <option value="adaptive">Genre-automatisch</option><option value="cinematic">Filmisch</option>
    <option value="festival">Festival</option><option value="club">Club</option>
   </select></label>
   <label>V979 · Regiestärke {settings.liveShowStrengthV979}% <input type="range" min={0} max={100} step={5}
    disabled={!settings.enabled||!settings.virtualFx||!settings.liveShowDirectorV979}
    value={settings.liveShowStrengthV979} onChange={e=>save({liveShowStrengthV979:Number(e.target.value)})}/></label>
   <button type="button" disabled={!settings.enabled||!settings.virtualFx}
    onClick={()=>save({liveShowDirectorV979:true,energyArcV975:true,
     intelligentTransitionsV976:true,storytellingV977:true,atmosphereV978:true})}>
    V975–V979 als gemeinsame Show aktivieren
   </button>
   <p className="settings-note">V979 synchronisiert die vorhandenen V975–V978-Stufen und begrenzt gemeinsame Licht- und Effektspitzen.
    Bestehende Einzel-Schalter bleiben wirksam. Keine Hardware-Kommandos, keine zusätzliche Render-Schleife,
    keine automatischen Übergänge bei manuellen Shows oder im Raspberry-Pi-Sparprofil.</p>
   <label><input type="checkbox" checked={settings.atmosphereV978}
    disabled={!settings.enabled||!settings.virtualFx}
    onChange={e=>save({atmosphereV978:e.target.checked})}/> V978: Smart Concert Atmosphere 2.0 – virtueller Genre-Nebel, Lichtstrahlen und Publikumsimpulse</label>
   <label>V978 · Atmosphäre <select aria-label="V978 Atmosphärenstil" value={settings.atmosphereModeV978}
    disabled={!settings.enabled||!settings.virtualFx||!settings.atmosphereV978}
    onChange={e=>save({atmosphereModeV978:e.target.value as ConcertSettingsV958['atmosphereModeV978']})}>
    <option value="subtle">Dezent</option><option value="balanced">Ausgewogen</option><option value="immersive">Immersiv</option>
   </select></label>
   <label>V978 · Stärke {settings.atmosphereStrengthV978}% <input type="range" min={0} max={100} step={5}
    disabled={!settings.enabled||!settings.virtualFx||!settings.atmosphereV978}
    value={settings.atmosphereStrengthV978} onChange={e=>save({atmosphereStrengthV978:Number(e.target.value)})}/></label>
   <label><input type="checkbox" checked={settings.atmosphereFogV978}
    disabled={!settings.enabled||!settings.virtualFx||!settings.atmosphereV978}
    onChange={e=>save({atmosphereFogV978:e.target.checked})}/> V978: Dynamischer virtueller Bodennebel</label>
   <label><input type="checkbox" checked={settings.atmosphereBeamsV978}
    disabled={!settings.enabled||!settings.virtualFx||!settings.atmosphereV978}
    onChange={e=>save({atmosphereBeamsV978:e.target.checked})}/> V978: Sanft schwenkende virtuelle Lichtkegel</label>
   <label><input type="checkbox" checked={settings.atmosphereCrowdV978}
    disabled={!settings.enabled||!settings.virtualFx||!settings.atmosphereV978}
    onChange={e=>save({atmosphereCrowdV978:e.target.checked})}/> V978: Ruhige Publikumsrand-Impulse (keine neuen Avatare)</label>
   <p className="settings-note">V978 verändert nur bestätigte virtuelle Songabschnitte. Bei manuellen Shows, reduzierter Bewegung, kompaktem FX-Modus oder dem Raspberry-Pi-Sparprofil bleibt die Erweiterung aus. Govee/Alexa erhalten keine zusätzlichen Befehle.</p>
   <label><input type="checkbox" checked={settings.volumetricV972}
    disabled={!settings.enabled||!settings.virtualFx||!settings.immersiveV966}
    onChange={e=>save({volumetricV972:e.target.checked})}/>
    V972: Weiche Lichtvolumen, Tiefendunst und Bodennebel (nur virtuell, keine Lichtblitze)</label>
   <label>V972 Atmosphärenstärke: {settings.volumetricStrengthV972}% <input type="range" min={0} max={100} step={5}
    value={settings.volumetricStrengthV972} disabled={!settings.enabled||!settings.virtualFx||!settings.immersiveV966||!settings.volumetricV972}
    onChange={e=>save({volumetricStrengthV972:Number(e.target.value)})}/></label>
   <label>V972 Performance-Profil <select aria-label="Volumetrische Atmosphäre Profil" value={settings.volumetricQualityV972}
    disabled={!settings.enabled||!settings.virtualFx||!settings.immersiveV966||!settings.volumetricV972}
    onChange={e=>save({volumetricQualityV972:e.target.value as ConcertSettingsV958['volumetricQualityV972']})}>
    <option value="eco">Eco – Raspberry Pi / 4 Ebenen</option>
    <option value="balanced">Balanced – 7 Ebenen</option>
    <option value="cinematic">Cinematic – 10 Ebenen</option>
   </select></label>
   <h4>V989 · Volumetric Atmosphere 2.0</h4>
   <label><input type="checkbox" checked={settings.depthAtmosphereV989}
    disabled={!settings.enabled||!settings.virtualFx||!settings.immersiveV966||!settings.volumetricV972}
    onChange={e=>save({depthAtmosphereV989:e.target.checked})}/>
    V989: Zusätzliche sanfte Lichtkegel und 3D-Bodennebel aktivieren (nur virtuelle Bühne)</label>
   <label>V989 · Tiefenmodus <select aria-label="V989 Tiefenmodus" value={settings.depthStyleV989}
    disabled={!settings.depthAtmosphereV989||!settings.volumetricV972||!settings.enabled||!settings.virtualFx}
    onChange={e=>save({depthStyleV989:e.target.value as ConcertSettingsV958['depthStyleV989']})}>
    <option value="auto">Automatisch nach bestätigter Songphase</option>
    <option value="soft-beams">Weiche räumliche Lichtkegel</option>
    <option value="ground-fog">Tiefliegender Bodennebel</option>
   </select></label>
   <label>V989 · Tiefe {settings.depthStrengthV989}% <input type="range" min={0} max={100} step={5}
    value={settings.depthStrengthV989}
    disabled={!settings.depthAtmosphereV989||!settings.volumetricV972||!settings.enabled||!settings.virtualFx}
    onChange={e=>save({depthStrengthV989:Number(e.target.value)})}/></label>
   <p className="settings-note">V989 ergänzt V972 nur nach manueller Aktivierung: Eco 2, Balanced 4,
    Cinematic 6 zusätzliche transparente Ebenen. Auf langsamer Hardware und bei manuell
    inszenierten Szenen bleibt V989 automatisch aus; reduzierte Bewegung friert die Atmosphäre ein.
    Diese Grafik nutzt weiche Shader-Ebenen statt aufwendigem Raymarching. Keine Gerätebefehle oder Blitze.</p>
   <label>Einfluss {settings.strength}% <input type="range" min={0} max={100} value={settings.strength} onChange={e=>save({strength:Number(e.target.value)})}/></label>
  </div>
  {settings.hardwareSync&&<p className="settings-note" role="status">Neue Govee-Cues werden nur bei aktivem Auto-Sync und echten bestätigten Songphasen berücksichtigt. Gespeicherte Shows und manuell gesetzte Kameracues bleiben unverändert. Keine Strobe-/Power-Kommandos.</p>}
  <AlexaConcertControlV967/>
  <h4>V939 / V945 / V946 · Konzertregie und Anti-Repetition</h4>
  <div className="govee-v958-settings"><label>Vorschauphase <select value={phase} onChange={e=>setPhase(e.target.value as ConcertPhaseV958)}>
   {phaseOptions.map(p=><option key={p} value={p}>{p}</option>)}
  </select></label><label>Songverlauf: {Math.round(position)}% <input aria-label="Vorschauposition" type="range" min={0} max={100} step={1} value={position} onChange={e=>setPosition(Number(e.target.value))}/></label></div>
  {scene&&<div className="govee-v958-preview" style={{border:`1px solid ${scene.palette[0]}`}}>
   <div className="govee-v958-wall" style={{background:`linear-gradient(125deg, ${scene.palette[0]}, ${scene.palette[1]})`}}>
    <span>LED WALL 3.0 · {scene.wall.toUpperCase()}</span><strong>{scene.phase.toUpperCase()}</strong>
   </div>
   <p><strong>Kamera:</strong> {scene.camera} · <strong>Formation:</strong> {scene.formation} · <strong>Genre:</strong> {scene.genre}</p>
   <p><strong>Effekte:</strong> {scene.effects.join(', ')||'ruhiger Moment'} · <strong>Energie:</strong> {Math.round(scene.intensity*100)}%</p>
   <small>Simulierte Vorschau, kein bestätigter Songabschnitt und keine echte LED-Rückmeldung.</small>
  </div>}
  <div className="govee-v958-summary"><strong>V938 Lichtshow-Probe:</strong> {rehearsal?.scenes.length} synthetische Szenen · <strong>V957 Qualitätswert:</strong> {rehearsal?.quality.score}/100 · Wiederholungen: {rehearsal?.quality.repetitions} · Überladungen: {rehearsal?.quality.overloaded}</div>
  <p className="settings-note">{realQuality?.available
   ?`V957 echte V318-Songabschnitte: ${realQuality.scenes.length} · Qualitätswert ${realQuality.quality.score}/100 · Szenenwiederholungen ${realQuality.quality.repetitions}`
   :'V957: Für den aktuellen Titel liegen keine bestätigten V318-Songabschnitte vor; die Qualitätsprobe oben ist ausschließlich synthetisch.'}</p>
  <h4>V960 · Concert Continuity Intelligence</h4>
  <p className="settings-note">Opt-in: echte benachbarte V318-Abschnitte werden ohne zusätzliche Netzwerk- oder Render-Schleife überblendet.
   V912-Lichtshows, eigene V354-Regie-Cues und manuelle Einstellungen behalten Vorrang.</p>
  <p className="settings-note">Synthetischer Ablauf: {continuity?.phaseChanges??0} Phasenwechsel,
   {continuity?.repeated??0} aufeinanderfolgende Kamera-/Formation-Wiederholungen.
   {realQuality?.available?` Importierte Songabschnitte: ${concertContinuityAuditV960(realQuality.scenes).phaseChanges} bestätigte Phasenwechsel.`
    :' Keine bestätigte Songanalyse – keine Hardware-Übergänge.'}</p>
  <h4>V977 · Smart Concert Storytelling</h4>
  <p className="settings-note">Opt-in: V975-Energiekurve und V976-Lichtüberblendungen werden durch eine langsame Dramaturgie über die tatsächliche Songposition ergänzt. Wiederkehrende bestätigte Hooks variieren dezent, Breaks lassen Luft und ein Outro-Finale setzt nur am echten Songende einen Akzent. Manuelle Bühnen-Cues und reduzierte Bewegung bleiben unangetastet. Ausschließlich virtuelle Effekte, keine Govee-/Alexa-Befehle.</p>
  <h4>V976 · Intelligent Concert Transitions</h4>
  <p className="settings-note">Opt-in: Farb-, Licht- und Effektübergänge zwischen wirklich erkannten, benachbarten Songabschnitten. Nur virtuelle Bühne; bestehende Kamera-Interpolation wird für automatische Übergaben verwendet. Manuelle V354-Cues und gespeicherte Lichtshows gewinnen. Für Raspberry-Pi-Eco und reduzierte Bewegung deaktiviert. Keine neuen Govee-Befehle, Timer oder WebGL-Objekte.</p>
  <h4>V975 · Adaptive Concert Energy Director</h4>
  <p className="settings-note">Opt-in: Gestaffelte Energie für Verse, Hooks, Build, Drop und Ruhephasen. Die Einstellungen beeinflussen nur die virtuelle Bühne, wenn echte V318-Songabschnitte bestätigt wurden. Kein zusätzlicher Timer, keine Govee-Lichtkommandos oder neuen Effekte. Im Raspberry-Pi-/Bewegungsreduktionsmodus deaktiviert.</p>
  <h4>V961 · Govee Concert Light Governor</h4>
  <p className="settings-note">Optional, nur während laufender Wiedergabe mit bestätigter V318-Songphase und eingeschalteter Govee-Konzertsteuerung. Neue 100%-Lichtspitzen werden abgefedert; Verdunkelung erfolgt sofort. V912-Lichtshows, eigene V354-Regie und die Wiederverbindung einer Lampe behalten Vorrang. Kein neuer LAN-Timer, keine zusätzliche Bridge-Abfrage, keine Power- oder Stroboskopbefehle.</p>
  <h4>V962 · Intelligent Concert Narrative</h4>
  <p className="settings-note">Optional: Verse bleiben fokussiert, Hooks werden voller, Builds steigern sich bis zum Drop, Breaks und Outros werden ruhiger. Bestätigte V318-Songabschnitte sind Pflicht. Die Lichtkurve darf nur dimmen und überschreibt weder V912-Lichtshows noch manuelle V354-Cues. Keine neuen LAN-Timer oder zusätzlichen Lichtkommandos.</p>
  <h4>V948 · Professional Timeline Studio</h4>
  <p className="settings-note">Zusätzliche manuelle Cues für den aktuellen Song. Keine automatische Änderung von V354 oder gespeicherten V912-Shows.</p>
  <div className="govee-v958-settings"><label>Kamera <select value={camera} onChange={e=>setCamera(e.target.value as ConcertCameraV940)}>{cameraOptions.map(v=><option key={v}>{v}</option>)}</select></label>
   <label>Tanz <select value={formation} onChange={e=>setFormation(e.target.value as ConcertDanceV941)}>{formationOptions.map(v=><option key={v}>{v}</option>)}</select></label>
   <label>Virtueller Effekt <select value={effect} onChange={e=>setEffect(e.target.value as ConcertFxV955)}>{fxOptions.map(v=><option key={v}>{v}</option>)}</select></label>
   <button type="button" disabled={!track?.id} onClick={addTimeline}>Cue an Vorschauposition speichern</button>
  </div>
  <p className="settings-note">{track?.id?`${settings.timeline[track.id]?.length||0} manuelle Cues für diesen Track gespeichert`:'Kein aktueller Song – Timeline-Eingabe gesperrt'}.</p>
  {track?.id&&(settings.timeline[track.id]||[]).length>0&&<div className="govee-v958-cues" aria-label="Gespeicherte Konzert-Cues">
   {(settings.timeline[track.id]||[]).map((cue,index)=><div key={`${cue.atMs}-${index}`} className="govee-v958-cue">
    <label>Start in Sekunden <input type="number" min={0} max={Math.floor(duration/1000)} value={Math.round(cue.atMs/1000)}
      onChange={e=>changeTimeline(index,{atMs:Math.round(Number(e.target.value)*1000)})}/></label>
    <label>Phase <select value={cue.phase} onChange={e=>changeTimeline(index,{phase:e.target.value as ConcertPhaseV958})}>
      {phaseOptions.map(v=><option key={v}>{v}</option>)}</select></label>
    <label>Kamera <select value={cue.camera||'wide'} onChange={e=>changeTimeline(index,{camera:e.target.value as ConcertCameraV940})}>
      {cameraOptions.map(v=><option key={v}>{v}</option>)}</select></label>
    <label>Formation <select value={cue.formation||'sync'} onChange={e=>changeTimeline(index,{formation:e.target.value as ConcertDanceV941})}>
      {formationOptions.map(v=><option key={v}>{v}</option>)}</select></label>
    <button type="button" onClick={()=>deleteTimeline(index)}>Cue entfernen</button>
   </div>)}
  </div>}
  <h4>V935 / V936 · Geräte-Rollen und Raumaufstellungen</h4>
  <div className="govee-v958-roles">{config.selectedIps.map((ip,index)=>{
   const model=devices.find(d=>d.ip===ip)?.sku||'Leuchte';
   return <label key={ip}>{model} · Leuchte {index+1}<select value={settings.roleOverrides[ip]||roles[index%roles.length]}
    onChange={e=>save({roleOverrides:{...settings.roleOverrides,[ip]:e.target.value as ConcertRoleV935}})}>
    {roles.map(role=><option key={role} value={role}>{role}</option>)}</select>
    {calibration&&<small>V932: optisch {latencyAnalysisV932(calibration.fixtures[ip]?.visualDelayMs??0,calibration.fixtures[ip]?.statusRoundtripMs??null).opticalMs} ms · Netzwerkdiagnose {calibration.fixtures[ip]?.statusRoundtripMs??'–'} ms</small>}
   </label>;})}</div>
  <div className="govee-v958-settings">
   <label>Presetname <input value={presetName} maxLength={40} onChange={e=>setPresetName(e.target.value)}/></label>
   <button type="button" disabled={!config.selectedIps.length} onClick={addPreset}>Aktuelle Raumaufstellung speichern</button>
   <select aria-label="Gespeichertes Raumpreset" value={selectedPreset} onChange={e=>setSelectedPreset(e.target.value)}><option value="">Preset wählen</option>
    {settings.presets.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select>
   <button type="button" disabled={!selectedPreset} onClick={applyPreset}>Gewähltes Preset anwenden</button>
  </div>
  <h4>V933 · Live Light Signal Monitor</h4>
  {!signals.length?<p className="settings-note">Noch kein V958-Lichtbefehl gesendet. Die Anzeige verwendet nur bestehende Versandereignisse.</p>
   :<div className="govee-v958-signals" aria-live="polite">{signals.map(item=><div key={item.fixture}>
    Leuchte {item.fixture}: {item.phase} · {item.cue} · {item.brightness}% · Songzeit {Math.round(item.atMs/1000)}s
   </div>)}</div>}
  <small>Nur erfolgreiche Bridge-HTTP-Antworten, keine Garantie sichtbarer LED-Reaktion und keine zusätzlichen Statusabfragen.</small>
  {notice&&<p className="settings-note" role="status">{notice}</p>}
  <p className="settings-note">V930: kontrollierter Wiederverbindungs-Backoff · V931: eigener Build-Gate · V934: sichere virtuelle Ruheszene · V937: Prioritätsmixer ohne Show-Überschreibung · V949–V955: ausschließlich virtuelle FX · V956: Finale nur bei bestätigtem Songende · V958: ein gemeinsamer Composer.</p>
 </section>;
}
