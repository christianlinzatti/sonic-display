"use client";
import { useCallback, useEffect, useState } from "react";
import { useMusic } from "@/context/MusicContext";
import {clearVocalEnvelopeOnTrackChangeV661} from "@/components/visualizer/vocalAnalysisStudioV661";
import {clearVisemeOnTrackChangeV644} from "@/components/visualizer/phonemeLipSyncV644";
import {clearNaturalDuetOnTrackChangeV664} from "@/components/visualizer/naturalDuetFeatureInteractionV664";
import {clearDeutschrapPerformanceOnTrackChangeV663} from "@/components/visualizer/expressiveDeutschrapPerformanceV663";
import dynamic from "next/dynamic";
import { recordLoadMetric } from "@/services/loading/loadingMetrics";

let settingsModule: Promise<typeof import("@/components/SettingsPanel")> | undefined;
let requestStarted = 0;
function preloadSettings(): Promise<typeof import("@/components/SettingsPanel")> {
  if (!settingsModule) {
    requestStarted = window.performance.now();
    settingsModule = import("@/components/SettingsPanel").then(module => {
      recordLoadMetric("Einstellungen: Modul", window.performance.now() - requestStarted);
      return module;
    }).catch(error => { settingsModule = undefined; throw error; });
  }
  return settingsModule;
}
const LazySettingsPanel = dynamic(() => preloadSettings().then(module => module.SettingsPanel), {
  ssr: false,
  loading: () => <aside className="settings-panel"><button className="settings-trigger" disabled>⚙ Einstellungen laden…</button></aside>,
});

/** Keep the heavy settings UI unmounted until the first open. Hover/focus warms its chunk. */
export function SmartLazySettings() {
  const {track}=useMusic();
  const trackId=track?.id??'';
  // This lightweight shell stays mounted while its heavy popover is closed.
  useEffect(()=>{clearVisemeOnTrackChangeV644(trackId);clearVocalEnvelopeOnTrackChangeV661(trackId);clearDeutschrapPerformanceOnTrackChangeV663(trackId);clearNaturalDuetOnTrackChangeV664(trackId);},[trackId]);
  const [requested, setRequested] = useState(false);
  const warm = useCallback(() => { void preloadSettings().catch(() => undefined); }, []);
  if (requested) return <LazySettingsPanel initiallyOpen />;
  return <aside className="settings-panel"><button className="settings-trigger"
    aria-expanded={false} onPointerEnter={warm} onFocus={warm}
    onClick={() => { warm(); setRequested(true); }}>⚙ Settings</button></aside>;
}
