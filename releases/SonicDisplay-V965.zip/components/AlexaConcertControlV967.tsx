'use client';
import {useEffect,useRef,useState} from 'react';
import {ALEXA_CONCERT_MESSAGES_V967,ALEXA_LOCAL_ENABLED_KEY_V967,
 applyAlexaConcertCommandV967,canApplyAlexaCommandV967,type AlexaConcertCommandV967}
 from '@/lib/alexaConcertV967';
import {loadConcertRoadmapV958,saveConcertRoadmapV958} from '@/lib/ultimateConcertRoadmapV958';

/** V967 explicitly opt-in receiver. Runs only while this studio is open.
 * Re-reads user-owned settings for each action; no Spotify or external hardware calls.
 */
export function AlexaConcertControlV967(){
 const [enabled,setEnabled]=useState(false);
 const [enabledSince,setEnabledSince]=useState(0);
 const [status,setStatus]=useState('Alexa noch nicht aktiviert.');
 const lastSeen=useRef('');
 useEffect(()=>{
  try{
   const saved=JSON.parse(localStorage.getItem(ALEXA_LOCAL_ENABLED_KEY_V967)||'null') as {enabled?:boolean;since?:number}|null;
   if(saved?.enabled===true&&typeof saved.since==='number'&&Number.isSafeInteger(saved.since)){
    setEnabled(true);setEnabledSince(saved.since);setStatus('Alexa-Empfang aktiv – Verbindungsstatus wird geprüft.');
   }
   lastSeen.current=sessionStorage.getItem('sonic-display:alexa-last-v967')||'';
  }catch{/* Private-browsing storage can be unavailable; remain disabled. */}
 },[]);
 const toggle=(next:boolean)=>{
  const since=next?Date.now():0;
  try{localStorage.setItem(ALEXA_LOCAL_ENABLED_KEY_V967,JSON.stringify({enabled:next,since}));}
  catch{setStatus('Alexa-Einstellung konnte nicht gespeichert werden.');return;}
  setEnabled(next);setEnabledSince(since);
  setStatus(next?'Alexa-Empfang aktiviert – Verbindung wird geprüft.':'Alexa-Empfang ausgeschaltet.');
 };
 const apply=(command:AlexaConcertCommandV967)=>{
  try{
   saveConcertRoadmapV958(applyAlexaConcertCommandV967(loadConcertRoadmapV958(),command));
   setStatus(`${ALEXA_CONCERT_MESSAGES_V967[command]} übernommen (nur virtuelle Bühne).`);
  }catch{setStatus('Befehl konnte nicht gespeichert werden. Prüfe den lokalen Speicher.');}
 };
 useEffect(()=>{
  if(!enabled||enabledSince<=0)return;
  let disposed=false,flight=false;
  const abort=new AbortController();
  const poll=async()=>{
   if(flight||disposed||document.visibilityState==='hidden')return;
   flight=true;
   try{
    const response=await fetch('/api/alexa/pending',{cache:'no-store',signal:abort.signal});
    if(disposed)return;
    if(response.status===401){setStatus('Alexa wartet: Spotify-Sitzung für dieses Display fehlt.');return;}
    if(response.status===503){setStatus('Alexa nicht konfiguriert: Lambda, Bridge-Secret und Upstash prüfen.');return;}
    if(!response.ok){setStatus('Alexa-Befehle momentan nicht erreichbar.');return;}
    const data=await response.json() as {command?:unknown};
    if(disposed)return;
    if(!data.command){setStatus(old=>old.includes('übernommen')?old:'Alexa-Empfang bereit (virtuelle Bühnenshow).');return;}
    if(!canApplyAlexaCommandV967(data.command,enabledSince,Date.now()))return;
    if(lastSeen.current===data.command.id)return;
    lastSeen.current=data.command.id;
    try{sessionStorage.setItem('sonic-display:alexa-last-v967',data.command.id);}catch{/* optional dedupe across reloads */}
    apply(data.command.command);
   }catch{if(!disposed)setStatus('Alexa-Verbindung vorübergehend unterbrochen.');}
   finally{flight=false;}
  };
  void poll();
  const timer=window.setInterval(()=>{void poll();},4000);
  const visible=()=>{if(document.visibilityState==='visible')void poll();};
  document.addEventListener('visibilitychange',visible);
  return()=>{disposed=true;abort.abort();window.clearInterval(timer);document.removeEventListener('visibilitychange',visible);};
 },[enabled,enabledSince]);
 return <section className="govee-v958" aria-label="V967 Alexa Sprachsteuerung">
  <h4>V967 · Alexa Konzertsteuerung (virtuell)</h4>
  <p className="settings-note">Alexa kann Arena, Festival, Club, ruhige Atmosphäre und virtuelle Effekte wählen oder die Konzertautomatik stoppen. Kein Spotify- oder Govee-Hardwarebefehl. Eine gültige Spotify-Sitzung und die geöffnete Seite sind für den Empfang erforderlich.</p>
  <div className="govee-v958-settings">
   <label><input type="checkbox" checked={enabled} onChange={e=>toggle(e.target.checked)}/> Alexa-Befehle auf diesem Display empfangen (opt-in)</label>
   <button type="button" onClick={()=>apply('festival')}>Festivalmodus lokal testen (ohne Alexa)</button>
  </div>
  <p className="settings-note" role="status">{status}</p>
  <small>Die Sprachverbindung muss einmalig in der Alexa Developer Console und in AWS Lambda eingerichtet werden. Befehle werden maximal 75 Sekunden bereitgehalten; manuelle Bühnen-Timelines behalten Vorrang.</small>
 </section>;
}
